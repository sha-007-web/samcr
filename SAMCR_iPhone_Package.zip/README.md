# SAMCR iPhone CRM – first version

This is an iPhone-friendly Progressive Web App (PWA) starter.

## What works now
- Add/edit/delete clients and classify them as Negative, Positive/Potential, or Converted
- Add and complete follow-ups
- Record sales, payments and meetings
- Basic priority suggestions based on saved CRM data
- Export/import a JSON backup
- Responsive layout for iPhone

## Important limitations
- Records are stored locally in the browser on this device. They are not synced to a cloud database.
- AI web research across company websites, public LinkedIn/Facebook and news is not connected yet.
- Background reminders and mobile push notifications are not active. They require a hosted backend, notification permission, and push service.
- This is not an App Store native app.

## How to use on iPhone
1. Upload the contents of this folder to an HTTPS static hosting service (for example, your own website or a static hosting provider).
2. Open the HTTPS link in Safari on your iPhone.
3. Tap Share → Add to Home Screen → Add.
4. Open SAMCR from the new Home Screen icon.
5. Export a backup regularly from More → Export Backup.

Do not clear Safari website data unless you have exported a backup.
